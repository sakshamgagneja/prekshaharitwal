# [50 Projects In 50 Days - 43 Feedback UI Design](https://arpadgbondor.github.io/50_Projects_In_50_Days-43_Feedback_UI_Design/)

## Udemy - 50 Projects In 50 Days - HTML, CSS & JavaScript
### Section 44: Day 43 - Feedback UI Design
